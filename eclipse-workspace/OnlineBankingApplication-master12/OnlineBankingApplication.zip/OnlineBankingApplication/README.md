# OnlineBankingApplication
A Spring Boot Online Banking System using JSP as FrontEnd and JPA, Hibernate, MySQL, Maven, Jackson, Spring Security as BackEnd 
