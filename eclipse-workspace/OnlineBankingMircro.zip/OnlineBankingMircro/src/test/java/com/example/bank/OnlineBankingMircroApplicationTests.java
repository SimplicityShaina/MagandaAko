package com.example.bank;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineBankingMircroApplicationTests {

	@Test
	void contextLoads() {
	}

}
