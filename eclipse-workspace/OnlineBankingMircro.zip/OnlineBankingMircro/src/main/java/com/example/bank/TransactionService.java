package com.example.bank;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;



@Service
public class TransactionService {
	
	@Autowired
	TransactionRepository transactionRepository;
	
	
	public Transaction saveTransaction(Transaction transaction) {
		return transactionRepository.save(transaction);
		
	}
//	public List<Transaction> saveTransactions(List<Transaction> transactions) {
//		return transactionRepository.saveAll(transactions);
//		
//	}
	public List<Transaction> getTransactions(){
		return transactionRepository.findAll();
		
	}
	
	public Transaction getTransactionById(long id ) {
		return transactionRepository.findById(id).orElse(null);
		
	}
	
	public  Transaction getTransactionByfromAccount (long fromAccount) {
		return transactionRepository.findByFromAccount(fromAccount);
		
	}
	
	public String deleteTransaction(long id) {
		transactionRepository.deleteById(id);
		return "product removed !!" + id;
		
	}
	public Transaction updateTransaction(Transaction transaction) {
		Transaction existingTransaction=transactionRepository.findById(transaction.getId()).orElse(null);
		existingTransaction.setFromAccount(transaction.getFromAccount());
		existingTransaction.setToAccount(transaction.getToAccount());
		existingTransaction.setAmounttx(transaction.getAmounttx());
		return transactionRepository.save(existingTransaction);
		
	}


}
