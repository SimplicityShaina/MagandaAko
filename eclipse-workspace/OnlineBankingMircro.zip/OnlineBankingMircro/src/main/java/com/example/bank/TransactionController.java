package com.example.bank;

import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;



@RequestMapping("/bank")
public class TransactionController {
	
	
	@Autowired
	TransactionService transactionService;
	
	
	@GetMapping("/allTransactions")
	public List<Transaction> findAllTransactions(){
		return transactionService.getTransactions();
		
	}
	
	@GetMapping("/trans/{id}")
	public Transaction findTransactionById(@PathVariable long id ) {
		return transactionService.getTransactionById(id);
		
	}
	
	@GetMapping("/trans/{fromAccount}")
	public Transaction findTransactionByfromAccount (@PathVariable long fromAccount) {
		return transactionService.getTransactionByfromAccount(fromAccount);
		
	}

	@PutMapping("/updateTransac")
	public Transaction updateTransaction (@RequestBody Transaction transaction) {
		return transactionService.updateTransaction(transaction);
		
	}
	
	@DeleteMapping("/delete/{id}")
	public String deleteTransaction(long id) {
		return transactionService.deleteTransaction(id);
		
	}
		
}
