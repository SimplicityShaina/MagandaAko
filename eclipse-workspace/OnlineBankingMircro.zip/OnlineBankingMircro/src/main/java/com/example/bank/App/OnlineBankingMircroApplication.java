package com.example.bank.App;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlineBankingMircroApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlineBankingMircroApplication.class, args);
	}

}
