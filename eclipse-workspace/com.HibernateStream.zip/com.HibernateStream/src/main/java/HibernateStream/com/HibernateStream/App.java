package HibernateStream.com.HibernateStream;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


import HibernateStream.com.HibernateStream.movie;
import HibernateStream.com.HibernateStream.moviemain;


public class App 
{
    public static void main( String[] args )
    {
        
        ApplicationContext context=new ClassPathXmlApplicationContext("hibernet.config.xml");
        moviemain streamdao= (moviemain) context.getBean("moviemain");
        //Name, Sequence Number, Movie ID) values ('soresh', '333', 444, 123)
        movie streamMovie1 =new movie(3445,"444", 566,"333");
        System.out.println(streamMovie1);
        int i=streamdao.insert(streamMovie1);
        System.out.println("done"+i);
    }
}